﻿#Written by Mitchell Loe, the bestest intern ever at Ingham ISD

#Inspired to share since he created this for me before I had this eBook
#called '10 WAYS TO DETERMINE THE AGE OF A COMPUTER' shared
#with me from the author Garth Jones. (https://t.co/wHPw0aEnmc)

#Replace <FQDN_CONFIGMGR_SERVER> and <SITE_CODE>
#$ModelFile must exist with columns 'Model' and 'Year'

$ComputerAgeCount = 0
$TotalComputerAge = 0

$hostname = "<FQDN_CONFIGMGR_SERVER>"
$namespace = "root\sms\site_<SITE_CODE>"
$query = "select * from SMS_G_System_COMPUTER_SYSTEM"


Write-Host "Gathering SCCM Info"
$SCCMComputerInfo = gwmi -ComputerName $hostname -Namespace $namespace -Query $query

$logFilePath = 'C:\scripts\ComputerAge.csv'            ##Path for the log/simulation file

Write-Host "Importing CSV"
$ModelFile = Import-Csv -Path 'C:\scripts\ComputerModelReleaseYears.csv'

## Apend Array for log

$global:scriptSimulationData = @() ## Must be global varable for a function to edit

function Get-ModelReleaseYear($ComputerModel)
{
    foreach ($Model in $ModelFile)
    {
        #Write-Host $($Model.Model)
        #Write-Host $($ComputerModel)
        #Write-Host " "
        if ($Model.Model -like $ComputerModel)
        {
            return $Model.Year
        }
    }
    
}

foreach ($Computer in $SCCMComputerInfo)
{
    $ComputerName = $Computer.Name
    $ComputerDomain = $Computer.Domain
    $ComputerResourceID = $Computer.ResourceID
    $Model = $Computer.Model
    $Manufacturer = $Computer.Manufacturer
    $ComputerAge = (Get-Date).Year - (Get-ModelReleaseYear $Model)
    if ($ComputerAge -eq (Get-Date -Format yyyy))
    {
        $ComputerAge = ""
    }
    else
    {
        $ComputerAgeCount = $ComputerAgeCount + 1
        $TotalComputerAge = $ComputerAge + $TotalComputerAge
    }
    

    ##Coloumns for excel file
    $tempObject = New-Object PSObject -Property @{
        "Name" = $ComputerName
        "Domain" = $ComputerDomain
        "ResourceID" = $ComputerResourceID
        "Model" = $Model
        "Manufacturer" = $Manufacturer
        "Age (Years)" = $ComputerAge
    }
    $global:scriptSimulationData += $tempObject  ##append to array
}

$global:scriptSimulationData | Export-Csv -Path $logFilePath -NoTypeInformation

$AverageAge = $TotalComputerAge / $ComputerAgeCount
Write-Host $AverageAge

Write-Host '########### JOB COMPLETE ############'